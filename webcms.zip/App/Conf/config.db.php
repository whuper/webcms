<?php return array (
  'DB_TYPE' => 'mysql',
  'DB_HOST' => '127.0.0.1',
  'DB_PORT' => '3306',
  'DB_USER' => 'root',
  'DB_PWD' => '888990',
  'DB_NAME' => 'newbus',
  'DB_PREFIX' => 'tp_',
);?>
