﻿document.write('<script type="text/javascript" src="jquery.jBox-2.3.min.js"><\/script>');
document.write('<script type="text/javascript" src="i18n/jquery.jBox-zh-CN.js"><\/script>');
document.write('<link rel="stylesheet" type="text/css" href="css/style.css" />');