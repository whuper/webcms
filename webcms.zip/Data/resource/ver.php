<?php return array (
  'YYCMS_VER' => '1.3',
  'YYCMS_TIME' => '20140423',
);?>