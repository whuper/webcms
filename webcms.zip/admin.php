<?php
header('location:index.php?g=Manage');
?>